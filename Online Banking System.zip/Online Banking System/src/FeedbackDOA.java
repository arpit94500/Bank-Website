import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
public class FeedbackDOA {
	public static PreparedStatement dbConnect() throws ClassNotFoundException,SQLException
	{
		Class.forName("com.mysql.jdbc.Driver");
    	Connection c=DriverManager.getConnection("jdbc:mysql://localhost:3306/bank","root","arpit945@@");
    	PreparedStatement st = c.prepareStatement("insert into feedback values(?,?,?,?,?,?,?)");
    	return st;
	}
}
