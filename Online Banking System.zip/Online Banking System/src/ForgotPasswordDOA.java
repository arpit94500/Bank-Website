import java.sql.*;

public class ForgotPasswordDOA {
	public static Connection dbConnect() throws ClassNotFoundException,SQLException
	{		
			Class.forName("com.mysql.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/bank","root","arpit945@@");
			return con;		
	}			

}
