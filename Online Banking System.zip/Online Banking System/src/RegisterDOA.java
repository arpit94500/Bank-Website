import java.sql.*;
public class RegisterDOA {
	public static PreparedStatement dbConnect() throws ClassNotFoundException,SQLException
	{
		Class.forName("com.mysql.jdbc.Driver");
    	Connection c=DriverManager.getConnection("jdbc:mysql://localhost:3306/bank","root","arpit945@@");
    	PreparedStatement st = c.prepareStatement("insert into register values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
    	return st;
	}
}
