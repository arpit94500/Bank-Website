
	import java.sql.*;
	public class LoginDOA {
		public static PreparedStatement dbConnect() throws ClassNotFoundException,SQLException
		{		
				Class.forName("com.mysql.jdbc.Driver");
				Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/bank","root","arpit945@@");
				PreparedStatement ps;
				ps = con.prepareStatement("select Account_Number,Password,Email,First_Name,Middle_Name,Last_Name,Status from register where Email=? and Password=?");
				return ps;		
		}			
	}

