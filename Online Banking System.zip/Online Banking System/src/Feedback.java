

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class Feedback extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out= response.getWriter();
		try {
			PreparedStatement ps=FeedbackDOA.dbConnect();
			response.setContentType("text/html");
			ps.setLong(4,Long.parseLong(request.getParameter("account")));
			ps.setString(1,request.getParameter("name"));
			ps.setString(2,request.getParameter("email"));
			ps.setString(3,request.getParameter("date"));
			ps.setString(5,request.getParameter("query"));
			ps.setInt(6,Integer.parseInt(request.getParameter("status")));
			ps.setString(7,request.getParameter("actiondone"));
			ps.execute();
			response.sendRedirect("sc.html");
		}catch(Exception e)
		{
			HttpSession session= request.getSession();
			session.setAttribute("msg", e);
			response.sendRedirect("contact.jsp");
		}
	}

}
